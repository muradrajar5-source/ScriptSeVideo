Script Se Video Free — Android source prototype v0.2

اہم: یہ سورس پروجیکٹ ہے، تیار APK نہیں۔ اس میں cloud build workflow بھی شامل ہے، لیکن GitHub پر build چلانے کے لیے سورس کو GitHub repository میں رکھنا ہوگا۔

ابھی کیا کرتا ہے:
- اردو اسکرپٹ کو لائنوں کے مطابق مناظر میں تقسیم کرتا ہے۔
- 9:16، 1:1 اور 16:9 فریم میں ٹیکسٹ/سب ٹائٹل کے ساتھ سادہ ویڈیو بناتا ہے۔
- 60، 90 یا 120 سیکنڈ کا دورانیہ منتخب کرنے دیتا ہے۔
- SRT سب ٹائٹل فائل الگ ڈاؤن لوڈ کرتا ہے۔
- اگر Android WebView میں اردو آواز دستیاب ہو تو ڈیوائس کی Text-to-Speech سے اسکرپٹ پڑھ سکتا ہے۔ یہ آواز ویڈیو فائل میں شامل نہیں ہوتی۔
- WebView/Chrome کی MediaRecorder سہولت کام کرے تو WebM ویڈیو ڈاؤن لوڈ کرتا ہے؛ MP4 کی ضمانت نہیں۔
- کردار کی یکسانیت کے لیے نوٹس/prompt دکھاتا ہے، خود حقیقی AI کردار یا حرکت نہیں بناتا۔

موجودہ حدود:
- حقیقی AI حرکت کرتی ویڈیو، خودکار AI کلپس، آواز کو ویڈیو میں ملانا، اور MP4 export ابھی شامل نہیں۔
- APK خودکار طور پر اس چیٹ میں compile نہیں ہو سکی کیونکہ یہاں Android SDK/Gradle build environment دستیاب نہیں۔

Cloud build workflow:
- .github/workflows/build-apk.yml GitHub Actions کے لیے ہے۔
- اسے چلانے کے لیے GitHub پر repository میں ScriptSeVideo-Free فولڈر اور .github فولڈر موجود ہونے چاہییں۔
- پھر repository کے Actions tab میں “Build Script Se Video APK” چلائیں۔ کامیابی پر Artifacts میں ScriptSeVideo-debug-APK ڈاؤن لوڈ ہوگا۔
- Debug APK انسٹال کرتے وقت Android کی طرف سے unknown-app install اجازت مانگی جا سکتی ہے۔

یہ پروجیکٹ کسی AI ویڈیو سروس کے API key یا paid account کے بغیر حقیقی AI clips نہیں بنا سکتا۔
