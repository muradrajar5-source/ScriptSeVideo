
package com.scriptsevideo.free;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.ContentValues;
import android.content.ContentResolver;
import android.net.Uri;
import android.provider.MediaStore;
import android.widget.Toast;
import android.util.Base64;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Locale;

import org.json.JSONObject;

public class MainActivity extends Activity {

    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(
                    Locale.forLanguageTag("ur-PK")
                );

                ttsReady =
                    result != TextToSpeech.LANG_MISSING_DATA
                    && result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });

        web = new WebView(this);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new VideoSaver(), "Android");

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void selectVoice(String gender) {
        if (tts == null) return;

        try {
            String wanted = "female".equalsIgnoreCase(gender)
                ? "female woman zira sara sana girl"
                : "male man david mark boy";

            Voice fallback = null;
            Voice selected = null;

            if (tts.getVoices() == null) return;

            for (Voice voice : tts.getVoices()) {
                Locale locale = voice.getLocale();

                if (locale == null ||
                    !"ur".equalsIgnoreCase(locale.getLanguage())) {
                    continue;
                }

                if (fallback == null) {
                    fallback = voice;
                }

                String name =
                    voice.getName().toLowerCase(Locale.ROOT);

                for (String word : wanted.split(" ")) {
                    if (name.contains(word)) {
                        selected = voice;
                        break;
                    }
                }

                if (selected != null) break;
            }

            if (selected != null) {
                tts.setVoice(selected);
            } else if (fallback != null) {
                tts.setVoice(fallback);
            }
        } catch (Exception ignored) {
            // Use the phone's default TTS voice.
        }
    }

    private class VideoSaver {

        @JavascriptInterface
        public void speakText(String text, String gender) {
            runOnUiThread(() -> {
                if (!ttsReady || tts == null) {
                    Toast.makeText(
                        MainActivity.this,
                        "اردو آواز تیار نہیں۔ TTS سیٹنگ چیک کریں۔",
                        Toast.LENGTH_LONG
                    ).show();
                    return;
                }

                selectVoice(gender);

                int result = tts.speak(
                    text,
                    TextToSpeech.QUEUE_FLUSH,
                    null,
                    "script-se-video-speech"
                );

                if (result == TextToSpeech.ERROR) {
                    Toast.makeText(
                        MainActivity.this,
                        "آواز نہیں چل سکی۔",
                        Toast.LENGTH_LONG
                    ).show();
                }
            });
        }

        @JavascriptInterface
        public void stopSpeech() {
            runOnUiThread(() -> {
                if (tts != null) {
                    tts.stop();
                }
            });
        }

        @JavascriptInterface
        public void makeSpeechFile(String text, String gender) {
            runOnUiThread(() -> {
                if (!ttsReady || tts == null) {
                    reportSpeechError("اردو آواز تیار نہیں");
                    return;
                }

                selectVoice(gender);

                File audioFile = new File(
                    getCacheDir(),
                    "script-se-video-voice.wav"
                );

                String id =
                    "script-video-" + System.currentTimeMillis();

                tts.setOnUtteranceProgressListener(
                    new UtteranceProgressListener() {

                        @Override
                        public void onStart(String utteranceId) {
                        }

                        @Override
                        public void onDone(String utteranceId) {
                            if (!id.equals(utteranceId)) return;

                            runOnUiThread(() -> {
                                if (web != null &&
                                    audioFile.exists() &&
                                    audioFile.length() > 0) {

                                    String fileUri = JSONObject.quote(
                                        Uri.fromFile(audioFile).toString()
                                    );

                                    web.evaluateJavascript(
                                        "window.onSpeechFileReady && " +
                                        "window.onSpeechFileReady(" +
                                        fileUri + ")",
                                        null
                                    );
                                } else {
                                    reportSpeechError(
                                        "آواز کی فائل نہیں ملی"
                                    );
                                }
                            });
                        }

                        @Override
                        public void onError(String utteranceId) {
                            if (!id.equals(utteranceId)) return;

                            runOnUiThread(() ->
                                reportSpeechError(
                                    "آواز کی فائل تیار نہیں ہوئی"
                                )
                            );
                        }
                    }
                );

                int result = tts.synthesizeToFile(
                    text,
                    new Bundle(),
                    audioFile,
                    id
                );

                if (result == TextToSpeech.ERROR) {
                    reportSpeechError("آواز بنانے میں خرابی");
                }
            });
        }

        private void reportSpeechError(String message) {
            if (web != null) {
                web.evaluateJavascript(
                    "window.onSpeechFileError && " +
                    "window.onSpeechFileError(" +
                    JSONObject.quote(message) + ")",
                    null
                );
            }

            Toast.makeText(
                MainActivity.this,
                message,
                Toast.LENGTH_LONG
            ).show();
        }

        @JavascriptInterface
        public void saveVideo(String dataUrl, String filename) {
            try {
                int comma = dataUrl.indexOf(",");

                if (comma < 0) {
                    throw new Exception("Invalid video data");
                }

                String encoded = dataUrl.substring(comma + 1);

                byte[] data = Base64.decode(
                    encoded,
                    Base64.DEFAULT
                );

                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();

                    values.put(
                        MediaStore.MediaColumns.DISPLAY_NAME,
                        filename
                    );

                    values.put(
                        MediaStore.MediaColumns.MIME_TYPE,
                        "video/webm"
                    );

                    values.put(
                        MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS
                    );

                    ContentResolver resolver = getContentResolver();

                    Uri uri = resolver.insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        values
                    );

                    if (uri == null) {
                        throw new Exception(
                            "File could not be created"
                        );
                    }

                    try (OutputStream out =
                             resolver.openOutputStream(uri)) {
                        if (out == null) {
                            throw new Exception(
                                "File could not be opened"
                            );
                        }

                        out.write(data);
                    }
                } else {
                    File folder = getExternalFilesDir(
                        Environment.DIRECTORY_DOWNLOADS
                    );

                    if (folder == null) {
                        throw new Exception("Folder unavailable");
                    }

                    File file = new File(folder, filename);

                    try (FileOutputStream out =
                             new FileOutputStream(file)) {
                        out.write(data);
                    }
                }

                runOnUiThread(() ->
                    Toast.makeText(
                        MainActivity.this,
                        "ویڈیو محفوظ ہو گئی",
                        Toast.LENGTH_LONG
                    ).show()
                );

            } catch (Exception e) {
                runOnUiThread(() ->
                    Toast.makeText(
                        MainActivity.this,
                        "ویڈیو محفوظ نہیں ہوئی: " +
                            e.getMessage(),
                        Toast.LENGTH_LONG
                    ).show()
                );
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("Android");
            web.destroy();
            web = null;
        }

        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }

        super.onDestroy();
    }
}
