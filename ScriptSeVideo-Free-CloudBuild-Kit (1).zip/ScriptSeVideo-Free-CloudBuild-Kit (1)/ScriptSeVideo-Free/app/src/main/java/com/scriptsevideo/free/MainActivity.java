package com.scriptsevideo.free;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.content.ContentValues;
import android.content.ContentResolver;
import android.net.Uri;
import android.provider.MediaStore;
import android.widget.Toast;
import android.util.Base64;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import org.json.JSONObject;

import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {

    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    private String pendingSpeakText = null;
    private String pendingSpeakGender = "female";

    private String pendingFileText = null;
    private String pendingFileGender = "female";

    private String currentFileUtteranceId = null;
    private File speechFile;

    private static final String LOCAL_HOST = "scriptsevideo.local";
    private static final String SPEECH_FILE_NAME =
            "script-se-video-voice.wav";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        speechFile = new File(getCacheDir(), SPEECH_FILE_NAME);

        // Initialize Android Text-to-Speech.
        tts = new TextToSpeech(
                getApplicationContext(),
                status -> {
                    if (status == TextToSpeech.SUCCESS) {
                        int result = tts.setLanguage(
                                new Locale("ur", "PK")
                        );

                        tts.setSpeechRate(0.9f);
                        ttsReady = result != TextToSpeech.LANG_MISSING_DATA
                                && result != TextToSpeech.LANG_NOT_SUPPORTED;

                        tts.setOnUtteranceProgressListener(
                                new UtteranceProgressListener() {

                                    @Override
                                    public void onStart(String utteranceId) {
                                        // Speech started.
                                    }

                                    @Override
                                    public void onDone(String utteranceId) {
                                        if (utteranceId != null
                                                && utteranceId.equals(
                                                currentFileUtteranceId)) {
                                            notifySpeechFileReady(
                                                    "https://" + LOCAL_HOST
                                                    + "/cache/"
                                                    + SPEECH_FILE_NAME
                                            );
                                        }
                                    }

                                    @Override
                                    public void onError(String utteranceId) {
                                        if (utteranceId != null
                                                && utteranceId.equals(
                                                currentFileUtteranceId)) {
                                            notifySpeechFileReady("");
                                        }
                                    }

                                    @Override
                                    public void onError(
                                            String utteranceId,
                                            int errorCode
                                    ) {
                                        if (utteranceId != null
                                                && utteranceId.equals(
                                                currentFileUtteranceId)) {
                                            notifySpeechFileReady("");
                                        }
                                    }
                                }
                        );

                        if (ttsReady && pendingSpeakText != null) {
                            String text = pendingSpeakText;
                            String gender = pendingSpeakGender;

                            pendingSpeakText = null;
                            speakTextNow(text, gender);
                        }

                        if (ttsReady && pendingFileText != null) {
                            String text = pendingFileText;
                            String gender = pendingFileGender;

                            pendingFileText = null;
                            makeSpeechFileNow(text, gender);
                        }

                    } else {
                        ttsReady = false;

                        if (pendingFileText != null) {
                            pendingFileText = null;
                            notifySpeechFileReady("");
                        }
                    }
                }
        );

        web = new WebView(this);

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        web.setWebViewClient(new WebViewClient() {

            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view,
                    WebResourceRequest request
            ) {
                Uri uri = request.getUrl();

                if (!LOCAL_HOST.equals(uri.getHost())) {
                    return super.shouldInterceptRequest(view, request);
                }

                try {
                    String path = uri.getPath();

                    // Serve the HTML app from the same local HTTPS origin.
                    if ("/assets/index.html".equals(path)) {
                        InputStream input =
                                getAssets().open("index.html");

                        return new WebResourceResponse(
                                "text/html",
                                "UTF-8",
                                input
                        );
                    }

                    // Serve the generated voice file from the same origin.
                    if (("/cache/" + SPEECH_FILE_NAME).equals(path)) {
                        if (speechFile != null && speechFile.exists()) {
                            return new WebResourceResponse(
                                    "audio/wav",
                                    null,
                                    new FileInputStream(speechFile)
                            );
                        }

                        return new WebResourceResponse(
                                "text/plain",
                                "UTF-8",
                                404,
                                "Not Found",
                                null,
                                null
                        );
                    }

                } catch (Exception e) {
                    return new WebResourceResponse(
                            "text/plain",
                            "UTF-8",
                            500,
                            "Local File Error",
                            null,
                            null
                    );
                }

                return super.shouldInterceptRequest(view, request);
            }
        });

        web.setWebChromeClient(new WebChromeClient());

        // Keep the existing Android.saveVideo() interface.
        web.addJavascriptInterface(new VideoSaver(), "Android");

        setContentView(web);

        // Use the same origin for HTML and generated audio.
        web.loadUrl("https://" + LOCAL_HOST + "/assets/index.html");
    }

    // Select a voice where a matching gender name is available.
    private void selectVoiceGender(String gender) {
        if (tts == null) {
            return;
        }

        try {
            Set<Voice> voices = tts.getVoices();

            if (voices == null) {
                return;
            }

            String wanted = gender == null
                    ? "female"
                    : gender.toLowerCase(Locale.ROOT);

            for (Voice voice : voices) {
                if (voice == null || voice.getLocale() == null) {
                    continue;
                }

                if (!"ur".equalsIgnoreCase(
                        voice.getLocale().getLanguage())) {
                    continue;
                }

                String name = voice.getName().toLowerCase(Locale.ROOT);

                if (name.contains(wanted)) {
                    tts.setVoice(voice);
                    return;
                }
            }

        } catch (Exception ignored) {
            // Keep the device's default voice if no match is available.
        }
    }

    private void speakTextNow(String text, String gender) {
        if (tts == null || !ttsReady || text == null
                || text.trim().isEmpty()) {
            return;
        }

        selectVoiceGender(gender);

        Bundle params = new Bundle();

        tts.speak(
                text,
                TextToSpeech.QUEUE_FLUSH,
                params,
                "preview_" + UUID.randomUUID().toString()
        );
    }

    // Generate a speech file and notify JavaScript when it is ready.
    private void makeSpeechFileNow(String text, String gender) {
        if (tts == null || !ttsReady || text == null
                || text.trim().isEmpty()) {
            notifySpeechFileReady("");
            return;
        }

        try {
            selectVoiceGender(gender);

            if (speechFile.exists()) {
                speechFile.delete();
            }

            currentFileUtteranceId =
                    "speech_file_" + UUID.randomUUID().toString();

            Bundle params = new Bundle();

            int result = tts.synthesizeToFile(
                    text,
                    params,
                    speechFile,
                    currentFileUtteranceId
            );

            if (result == TextToSpeech.ERROR) {
                currentFileUtteranceId = null;
                notifySpeechFileReady("");
            }

        } catch (Exception e) {
            currentFileUtteranceId = null;
            notifySpeechFileReady("");
        }
    }

    // JavaScript callback: window.onSpeechFileReady(uri)
    private void notifySpeechFileReady(String uri) {
        runOnUiThread(() -> {
            if (web == null) {
                return;
            }

            String safeUri = JSONObject.quote(uri);

            web.evaluateJavascript(
                    "if (typeof window.onSpeechFileReady === 'function') {"
                    + "window.onSpeechFileReady("
                    + safeUri
                    + ");"
                    + "}",
                    null
            );
        });
    }

    private class VideoSaver {

        @JavascriptInterface
        public void speakText(String text, String gender) {
            runOnUiThread(() -> {
                if (ttsReady) {
                    speakTextNow(text, gender);
                } else {
                    pendingSpeakText = text;
                    pendingSpeakGender = gender;
                }
            });
        }

        @JavascriptInterface
        public void makeSpeechFile(String text, String gender) {
            runOnUiThread(() -> {
                if (ttsReady) {
                    makeSpeechFileNow(text, gender);
                } else {
                    pendingFileText = text;
                    pendingFileGender = gender;
                }
            });
        }

        @JavascriptInterface
        public void saveVideo(String dataUrl, String filename) {
            try {
                int comma = dataUrl.indexOf(",");

                if (comma < 0) {
                    throw new Exception("Invalid video data");
                }

                String encoded = dataUrl.substring(comma + 1);
                byte[] data = Base64.decode(
                        encoded,
                        Base64.DEFAULT
                );

                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();

                    values.put(
                            MediaStore.MediaColumns.DISPLAY_NAME,
                            filename
                    );

                    values.put(
                            MediaStore.MediaColumns.MIME_TYPE,
                            "video/webm"
                    );

                    values.put(
                            MediaStore.MediaColumns.RELATIVE_PATH,
                            Environment.DIRECTORY_DOWNLOADS
                    );

                    ContentResolver resolver = getContentResolver();

                    Uri uri = resolver.insert(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                            values
                    );

                    if (uri == null) {
                        throw new Exception(
                                "File could not be created"
                        );
                    }

                    try (OutputStream out =
                                 resolver.openOutputStream(uri)) {
                        if (out == null) {
                            throw new Exception(
                                    "File could not be opened"
                            );
                        }

                        out.write(data);
                    }

                } else {
                    File folder = getExternalFilesDir(
                            Environment.DIRECTORY_DOWNLOADS
                    );

                    if (folder == null) {
                        throw new Exception("Folder unavailable");
                    }

                    File file = new File(folder, filename);

                    try (FileOutputStream out =
                                 new FileOutputStream(file)) {
                        out.write(data);
                    }
                }

                runOnUiThread(() ->
                        Toast.makeText(
                                MainActivity.this,
                                "ویڈیو محفوظ ہو گئی",
                                Toast.LENGTH_LONG
                        ).show()
                );

            } catch (Exception e) {
                runOnUiThread(() ->
                        Toast.makeText(
                                MainActivity.this,
                                "ویڈیو محفوظ نہیں ہوئی: "
                                        + e.getMessage(),
                                Toast.LENGTH_LONG
                        ).show()
                );
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }

        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }

        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}